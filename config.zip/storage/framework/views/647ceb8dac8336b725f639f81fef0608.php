<header class="site-header">
    <div class="header-wrapper">
        <div class="me-auto flex-grow-1 d-flex align-items-center">
            <!-- Admin Panel Branding -->
            <span class="navbar-brand text-dark fw-bold me-3"></span>

            <ul class="list-unstyled header-menu-nav" id="headerMenuToggle">
                <li class="hdr-itm mob-hamburger">
                    <a href="#!" class="app-head-link" id="mobile-collapse">
                        <div class="hamburger hamburger-arrowturn">
                            <div class="hamburger-box">
                                <div class="hamburger-inner"></div>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>

            <!-- Search -->
            
        </div>

        <nav class="ms-auto">
            <ul class="header-menu-nav list-unstyled">
                <!-- Notifications -->
                <li class="hdr-itm dropdown ntf-dropdown">
                    <!-- ... (notification dropdown unchanged) -->
                </li>

                <!-- Language Dropdown -->
                <li class="hdr-itm dropdown lng-dropdown">
                    <!-- ... (language dropdown unchanged) -->
                </li>

                <!-- User Dropdown -->
                <li class="hdr-itm dropdown user-dropdown">
                    <a class="app-head-link dropdown-toggle no-caret me-0" data-bs-toggle="dropdown" href="#"
                        role="button" aria-haspopup="false" aria-expanded="false">
                        <span class="avtar"><img
                                src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMQEhMTERIWFRUWFRgWGBUVGRcXFRgXFRMaGBUYGBcdHiggGB0lGxUYITIiJikrLi4uGiAzODMtNygtLisBCgoKDg0OGhAQGysiICY1LS0tNS0tLjctMi0vLS4tNS0tLy0tLS0vLS0tMi0uKy0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABgcEBQIDCAH/xABHEAACAQIDBQUEBwUECQUAAAABAgADEQQSIQUGMUFREyJhcYEHMpGhFCNCUoKx8GJyksHRorLh8QgVJDM0Q2Nz0xaDwsPS/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QAJBEBAAICAwACAQUBAAAAAAAAAAECAxESITEEUUEUIjNhcSP/2gAMAwEAAhEDEQA/ALxiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICInRjcbToIXrVEpoOL1GCKPNibQO+JG/wD17sy5Ax2HJ8Ki2/ivb5yJbR9sCd76LhWcIGzPVdFBK8BTyFw4NveuBzFxImYhMVmfFoAz7PPG6e/mLwZY5lq9oxepTq3AZ2N3dWFzTYnnYqRy5yzNje0+hW0rUKtE9RlrIT0XsyajfwSsXhecdoTuJh7P2pRxF+xqq+XRgD3kJFwHXihtyIBmZLsyIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiJBfadvcmDomnSxJTEMNEpZDUF/tMzAimvH7OY/ZtYkExG3fv5v7T2cpp0gKuJI0S/cp3GjVSNR1CjU6cB3hRO18ZXxdXtsXWepU5EhcqA8qaMpCD923jeavO9Rj32ZiSzMWIGpuWc8WJN+pJvx1namEopqyhzzZtB6KP53MymzatYhnLiCovmzAakVAuo8GUAD1HqJ9wjhQFPushB9SV/laYrCkVOQBSLGy3AsGGbu89LwxuALgEaqT7pB4gnodCDKL7d4BBKPqRr4EfeA/Vp2KvQ2mIMUrWSqCCNQD3XXxVv0DO8Ow/6g8O7U9QNH8xr4GRMLRZvNkbYdXQM7qyf7uohtVp+NNua6a0z3G4EA6izd1PaJmzUtoZEqUyA1ZLikVe3ZVWU601cMpzagEkNk0BppaoYBkNyDdeWo5HwI08j4SQ4RVbEYZiO5Up1aNS/A0bAtf0r1NZFbzWdLXx1vXf5eh4mo3QDjAYPtb9p9Go583vZuyXNfxvNvOpwkREBERAREQEREBERAREQEREBERAREQNftzbNHBUxVxDFaeYIWCswUt7pIUE2vpe3MTzJvSKVXGV3wilMOzllD8bsSWKryUm5APAEXsdB6d25sqnjKFXD1hdKi5TbiOasp5MCAQeoE8v71bEq7OxL4V6gcrYh1zKCre6SDqDbkLjxMrZemmJnCjKOA1PiT16n/AA5To1c3JsJwHTgBqSfmTJNsLdc1wHrhkpfZT3XqeJ5qvzPhzytaKxuW9azedQjBxSIdOI5kzlTxynhp4KQR4906D0tLW2fsKjT0o4dB4qgJ9Wtc+pmTjt0hilC1aYABvyU/EDMPS0x/UV346P0tteqiqYjT3lt91hYeitcfOduHWoLFaVTL4I5XwINtJcey9ycPQsURQfvBbv8Axtdpuqey6Y5H1lZ+TH4gj433KhUqBqhCEXawPQNfienMn1kq2Zj6TVkTL2lNFFPLmVe0S5NVFLC2aoCU1sMtrlCbifbxbm0cZQrEKBWVCab2Ga41AJGpXThwlV7t0qRqU2dmaxB7AAioxGuThYDlfgOdtZeLRaOSs14zNXpnZO0aeKopWpElHFxcWYEGzKwPusCCCORBmXI57PXJwFLMAHz1hUy3y9qMTUFYi+tjUDn1kjnY88iIgIiICIiAiIgIiICIiAiIgIiICIiAlK/6QuFvUwTjQmnXBPXK9GwP8bfOXVKx9vWFzYTD1APcrlT4B6Ln+9TQesifE19VPuJg1fEE1O+UTMgPAEMBmtzIv85bmw8MDmdhfkL/ABJ/L5yt/Z/s/wD3mIPjSTy0Zz465R+EyyMDtrCplonE0RUA1Q1EDAnUixPHXhPOz936etg/bjjf5bc6ToqYsD7LnyRv6TtXEIeDqfJgZzvrb1+N7flMGrBOKU8VrD8NQf3ZkUF5hmI6Nc/Nhm+c506oIJ6Eg+h/ynCti6aC71EUdWZQPmZJ/ra7I94jqv8AMSlNjBfpddl4DEMy/uHEtlHwIlr7v7ZoV6tsPiKdQr7wpur2BBtex6jjIjvHsMYbaZyABMUUqgcgwq2rgfiZH86hm9f45hzTP/aJWB7Pv+EbocXjbeX06tJLI9uAo/1fh2F/rVavrx/2io1b/wCySGei8ySIiAiIgIiICIiAiIgIiICIiAiIgIiICQL2uYzDVMBicOcRRFdFSsKRqJ2tqTrUayXzaorcucnsonEAMtZagV871e0DAE9pUq1FJvzIdSDfgALWy2OeS/GGuHHzn1jbKpOuzKK0WC1HDnO3Be0qklvEgHQdbSN47dChRFnq16j6XFNAdTw0sxF7HUm3HWTDYin6FhABcmgnO3va8Rr8PlJPR3fp9kUqU1YuF7QXdQ2U3TNlbvZT7t9RrY6mcUZONp39vRtj5UjX1CnNibv4TFhjTauMpALMKZUFr5c1hpfKeY4S3NxsCuHw4pCo9RlPeZzrY+6FH2UGth5zspbv06VNlppTpr7xyhixKg5SWdmNxc9eJ4T7u6LNU8VX+yW//UjLk5dRPScWPjG5jtGt/wDdqni6wP0h1Ci9SmNUzFQQRfQMVIPPS3WV9i9lYHD1Qlb6XYi9wtNdBe5GZbkCxvYcjL3xmykqBs332N/3jwPhYWmCu72Hepmq0gXFtSLnu2Cm4sGtlGp10HCWx5ePU+KZMXKNx6jewvZ+tMjE7OxdaliMO3epYpFAJtfsnyhSqtpqQdCDbUGSf2mVCKWGxCjvoK2UXHvNQLKp/HTUek2T4ZRcpo17km92P7RBuT4m/rNZv9SFTB4PtAMgxtLtARmBpjtGcEcwQvqJeuTlZjbFNIiUx3bx+FammHwuIo1ewppTK0qiOVCKFFwpNhpabiVdsqs7Y3AsbKTXZFRQoyUjg67MlwLspNME3uC1NSAOEtGdVLco25MlOE6IiJdQiIgIiICIiAiIgIiICIiAiIgIiICU5tnB5MbjaVrA1GZT1FZRWcj8dZvgekuOQP2ibJyumNUEqqinXsCSqKxNKsAOSF3DfsVCTolplmrNqdN/j3iuSNoZu1XH0bDZTqiZPWi5Q/NfnJ3RqBlDDgReVNuhtVM1ejmBy1qrUze+amzk6H7Wovfnmlk7DrXQr906eTf43nn5a6tL1Mc7pDu2zXCUKhJsSpVepZhZQBzNzMbYFDQv1OUDytc/H8jNDvft6gHFNqnepspCoM7Z1YOCQPFQLG3O3GaDZu+lSm+VFco1zesaanQcgi2t6XkxjtNelZyVidTK0MVi+zp1WYcFD34iwPeJ6WAN+g1nHDVxUUMPIjoeYP65iVdQ36qPVLVRVC+6FpGmVAPEspALfEC3LrLNg7w4V6gSjUy5rJ2bgqwIHdtf3umhPEybY5iO4UpeNzpKyZod+MQCuzsNcg1cQ7kAX7lKhUDX6C9RdZua9UILmVpX3lo4jbCNVqKtChSekrMbLnykuw5kknKANTYWjDEzMz/Rn11E/ae7p0+0x6m3dp0arE/tl0RCPDK1UeamWHI3uZs1kWpiKiFHr5ctNhZqdCmD2KMOTHM9RhyaoV+zJJPQx141iHm5b87zJERLsyIiAiIgIiICIiAiIgIiICIiAiIgIiIHkfb1V6ePxTDusuKr8LaEV36aSQDfpkw7CkctZhk/dBAJceItYeJmX7ctiHDbQNcACnihnW336aotUW8e634jIBSoltQCbdNZlekWnt1Y8k1r0kmzd1q9RKdaoWSnVGZStmZgddTeyk8db8eEkWE2DSpWy4d2PUuCx8T3wPhbymHuvvr2GGejVXMFUml46E5Gv0PPx8Jo8RvbiyxK1Ag+6EQj+0pP65TnvTNaZ71Drx5MFI7jcpVit1adUEii9JjwKMtx6FiPzkV2xsPEYJUqOTkLWVtFbMO8CFuSB3eMydkb64qlUBqsKii10KUxpcXIyqNbdZy3y3i+nVbrfs1AVQftEnVrfIeHnJxUy1nVp3CubJhtG6xqWZtnfyriKCoLioVy1GGg0OuX97Q+HCffY6p/1thQNdKpPkKLfHXKfSQyoMouOglw/wCj5sJr4jHOO6R2FLjc2YNVPS1wgv1VumvRSkV6hyZbzaO10RETRzkREBERAREQEREBERAREQEREBERAREQEj+82+eD2fZa9X6wi4pUwXqkcjlHug2PeYgaHWct9t4l2dhKlc2L6JSU8GqN7oPgACx/ZVjPMlfE1MVUeo7M7O2ZnbixP2m+WnACwFgJEytEbWFvjvwu2smCTDCmj1UtVdg1Ze+CSAoyobAg95riVy9I4YlKgIYNqNLqxW4524EEdLzf7uYYJiqHi5v1BSjUa5HPhN1vhu+cWoenbtk0FzYMt9VPjzB9Ocwvl43iJdWPFypMwgRIJJ4Am9un6Md0lf1+uEwgxBINwQbEHiCDqCJ2q01ZaZLU1I48ROvQWN/0Z0s/6+c+4TD1K9RaVFS7scqqOJPH0FgdYTENnu5sZ9oYmlRRSVzp2jDgtMsATfrbh1PrLH9n/tOajRoYd8PTNNEVFKHsmACC1yxKOxPEsaY11PEyS+z7dpMAtKmLGox7Sq/3mUcv2VJUAf4yl6Aszp91mX+FiD+UpjyctzCctOOol6j2RtelilY0yQyHK9NhlqU2tezryuCCDwIIIJBBmfKA3Q3oqUKlM6s9JbKPtVaI1fDn7xGr078HFrgO176wuIWqiVKbBkdQ6sNQysLqQeYIIM1iXPMadsRElBERAREQEREBERAREQEREBETjUcKCWIAAuSdAAOJJ5QOU+E24yvt4/axhKF0wgOLqDS6HLQB8a1iG/AG9JV+8W92M2hcYitamf8AkUrpS8m1zVPxEjwEjaYhtfbLvTTx1anQw1QVKVEHM6G6GoxtU14NlQKLjT61hykNwSKobje9jc9Dy004zK3dVXLsdFUkWHAi9gR420/DMLaINPtVPSw8mNhIaa6SHdHD9pUp4kjS9REF7jIqlWY+JJt+GSxTwB46jzKmxmn3LZWwdGw1XOp8D2jX+Oh9ZuHS/wAQR5jT8vzM87Lbdp29TDXjSNNJvDuxSxfeH1dUfbUDveDj7XnxkMxG6eKVyiJntm7wICkDUcTxPSWeeIPp8eHz/OZ2B2e1XXgv3v6dYpmtWNF8NLTvxVex9yMViamRl7K3FmsR7twdDY6kc+vSW5upuhQwCHs1u9u9WYAu1+QP2V04DpNrTpJRQ2FgNTzJ/qZl1DYBeY1b948R6cPjF8trx34rXHWs9OrDORUzD7JAH5t8dB+GUvvds0Yd6ddRYVGdKg5Zs7FW8yAbn9kS6FW3658T85W/tVKiiy2AvUQADrlLN8r/ABk4LzFoiFc1ImszKH0qpBVgbMMrA+PEflLw9lW3Fq0Xw5YZ6Rzotxc0aveWw6K+dABwCrKGwz3C/wDbT42N5tMLWVXw1V0DhKhQgsyHK3euKi96mRlIDDUXnoPOmNvUESBUNp4nBuKfalwdFw+0CKdU8dKGOW9OvoNFe7/eYSQ7P3ooVKgo1M+HxB4UMQMjtbj2bXKVh402aWZt5ERAREQEREBERAREQERECNb+7w19n4cVcPhu3JbISWslO47rOACSL6aW1I1EpjbGLxm0TfHVyy3uKK92iOn1Y0PmxYz0RiKC1FZHUMrAqyngQeIlNb27uPgattWpMfq3/wDg37Q+Y16gVttemkQxuCSmikKdWsBzOnX+kwWogqWW4txB1m+xtmpjqrXHqCP5zT16ioCoNy1/jzv6flIhafXHdyj/ALMbcWB+JF/zaY28rhqdKovBwPmAy/zmTu/Xy5qR5G6+R4fIW/CZj7bX6ioh40qqsP3ah7voM7L+GR+VnzdDbn0Vyj60n1NuKtwDjqLWBHgOljZuFotVANMZgQCGHu2PA34SmMEeMlG7W9VfA6JapSJuaTk214lG1KG/HQjjpc3mWbBy7r63w/J4ftt4tXD7FFj2h1II04C/PxImXs3Fioutgy6Mo5FTZreAIImk2Zv5gqw71Q0G5rWGUD/3BdPnfwmPjsXR7R2p1qbI9nBV0I1FmFweoLfinFNLR1MOyt628lvRihWroi6pTvVY8mZSBTXyzHN49mZspFdkbZwtHtWq4mirMVUA1FzFUBIOUG/vVH5cpibU9pGGQEYdHrNyJBp07+JYZvgvrJjHa3UQrOSldzMphisSlJGqVGCogLMxNgAPGUfvZto42oz2IQZsgPE3NyxHImwsOQHUmfdvbx4jGt9c/dButNO7TXxtfvHxJJ42teaase6fKdmHBw7n1x5vkc+o8dmzT3T52+H+cz63/D1PB6XzqAH5GYWAHcX1b4k2/XhNk9IstKiou9aoLDyIy/2inzmzB6Zw9Na+HQVUV1emuZXAZTdQSCDoZo9pbmoyFKLgUzqcNiF+kYU210Rjmp+BRgB0kmoUwiqo4KAB6C05y7JBNl4fH4WolJA+QkDs6zPicNYC7dlirdvRNgbCqrLwAIk7iICIiAiIgIiICIiAiIgJjbQwNPEU2pVVDIw1B+RB5EdZkxApLfXdKrgw3F6Le7UtwPJX6G/PgfkK8cdOWv6/Kera1JXUq6hlIsVIuCDxBB4yp98vZYwLVtn94ak4djqP+2x4j9lvjwErpflv1VNS4s68V104kc7ePMeImTteoKlLtRYhkKN0+/Sb+MAfj8J11qLU2ZHVkZTYqwKsp6EHUTlgKgDGm+qVARY8LniPzPxkStEtJgeB9Jk+Ux6FI03dDxUkfwm15kSys+vhY/5a/IkfmZ8LeXqGH8jOUQgHmB6E/nacrDxPn/ScYJgfZj4x7L+vOd9p0umeoijXmfIan5D5wmGy2fQ0VT0F78gBz6aDX1kz9mux/pe0qdTUpQ+sII5Uz9V5E1CHtx0PSRarVFMZL6vYknhkI0HqQfQHrLx9lWwjhcGKjg9piCKhvxWn/wApT+E5vNiOUiCZ6TQmBAE+yyhERAREQEREBERAREQEREBERAREQNPvBuzhcetsRSDECyuO7UXyca28OHhKu3i9j9dcxwdYVV4hKlkqqRqLN7jG/XLLpiExLyft/ZGJw1UNicPUolgA2ZTkzDu91/dbgvAzDnrtlBFiLg8jNBtDcjZ1e5qYOjc8WRezY+JZLG/rITM7eY4l/wCI9kWzW91a1P8Adqsf7+aYDexbBcsTi/4qH/hhG1HxL2w/sbwC+9VxL/vPTH92mJuMD7NNmUtRhQ5/6r1Kg/hZivyg2850abVGCU1Z3PBEBZj5KNTJtuv7M8fWqZnpdhTsO9WNi1+I7Id4WHI5ePwvvAbPo4dctClTpL92mioPgoEyY0bQnd32Z4PCkVKt8TVuTmqgZFJt7lLgBoLZsxFuMm0RJQREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQERED/2Q=="
                                alt=""></span>
                    </a>
                    <div class="dropdown-menu header-dropdown">
                        <ul class="p-0">
                            <li class="dropdown-item"><a href="#" class="drp-link">Edit Profile</a></li>
                            <hr class="dropdown-divider">
                            <li class="dropdown-item"><a href="#" class="drp-link"><span>Account Settings</span></a>
                            </li>
                            
                            <hr class="dropdown-divider">
                            <li class="dropdown-item">
                                <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-link text-danger p-0 m-0 d-flex align-items-center">
                                        <i data-feather="log-out" class="me-1"></i>
                                        <span>Logout</span>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </div>
</header>

<script>
    document.getElementById('logout-button').addEventListener('click', function () {
        // Find the logout form and submit it
        document.getElementById('logout-form').submit();
    });
</script><?php /**PATH C:\wamp64\www\projects\panel\resources\views/layouts/header.blade.php ENDPATH**/ ?>