<footer class="app-footer">
  <div class="footer-wrapper">
    <div class="py-1">
      <span class="text-muted">&copy; 2025, Techno Tronixs for a better web.</span>
    </div>
    
  </div>
</footer>

<!-- Required Js -->
<!-- <script src="../assets/js/plugins/jquery.min.js"></script>
<script src="../assets/js/plugins/popper.min.js"></script>
<script src="../assets/js/plugins/simplebar.min.js"></script>
<script src="../assets/js/plugins/bootstrap.min.js"></script>
<script src="../assets/js/plugins/feather.min.js"></script>
<script src="../assets/js/main.js"></script> --><?php /**PATH C:\wamp64\www\projects\panel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>