

<?php $__env->startSection('content'); ?>

<body class="theme-1">

</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('retailerLogin.layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\projects\panel\resources\views/customer/index.blade.php ENDPATH**/ ?>