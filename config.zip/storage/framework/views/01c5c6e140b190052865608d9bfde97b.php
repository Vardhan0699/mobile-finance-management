

<?php $__env->startSection('content'); ?>

    <body class="theme-1">
        <div class="page-content-wrapper">
            <div class="content-container">
                <div class="page-content">
                    <div class="content-header">
                        <h1>Product List</h1>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item">Product</li>
                            <li class="breadcrumb-item">Product List</li>
                        </ul>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card table-card">
                                        <div
                                            class="card-header card-header d-flex align-items-center justify-content-between">
                                            <h5 class="flex-grow-1">All Product</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table" id="pc-dt-export">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center">ID</th>
                                                            <th class="text-center">Date</th>
                                                            <th class="text-center">Pincode</th>
                                                            <th class="text-center">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $pincode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                <td class="text-center">
                                                                    <div class="d-flex align-items-center">
                                                                        <h6 class="mb-0"><?php echo e($index + 1); ?></h6>
                                                                    </div>
                                                                </td class="text-center">
                                                                <td class="text-center"><?php echo e($pin->created_at); ?></td>
                                                                <td class="text-center"><?php echo e($pin->name); ?></td>
                                                                <td class="text-end">
                                                                    <a href="<?php echo e(route('admin.brandEdit', $pin->id)); ?>"
                                                                        class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                                        title="Edit">
                                                                        <i class="ti ti-pencil"></i>
                                                                    </a>

                                                                    <form action="<?php echo e(route('admin.brandDestroy', $pin->id)); ?>"
                                                                        method="POST" style="display:inline-block;"
                                                                        onsubmit="return confirm('Are you sure you want to delete this brand?');">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button type="submit"
                                                                            class="btn btn-icon btn-sm text-danger"
                                                                            data-bs-toggle="tooltip" title="Delete">
                                                                            <i class="ti ti-archive"></i>
                                                                        </button>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="3" class="px-6 py-4 text-center text-gray-500">No
                                                                    brands found.</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-5">
                            <div class="dataTables_info" id="pc-dt-simple_info" role="status" aria-live="polite">Showing 1
                                to 5 of 5 entries</div>
                        </div>
                        <div class="col-sm-12 col-md-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="pc-dt-simple_paginate">
                                <ul class="pagination">
                                    <li class="paginate_button page-item previous disabled" id="pc-dt-simple_previous"><a
                                            aria-controls="pc-dt-simple" aria-disabled="true" aria-role="link"
                                            data-dt-idx="previous" tabindex="0" class="page-link">Previous</a></li>
                                    <li class="paginate_button page-item active"><a href="#" aria-controls="pc-dt-simple"
                                            aria-role="link" aria-current="page" data-dt-idx="0" tabindex="0"
                                            class="page-link">1</a></li>
                                    <li class="paginate_button page-item next disabled" id="pc-dt-simple_next"><a
                                            aria-controls="pc-dt-simple" aria-disabled="true" aria-role="link"
                                            data-dt-idx="next" tabindex="0" class="page-link">Next</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\projects\panel\resources\views/pincode/create.blade.php ENDPATH**/ ?>