<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\Product;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Models\Customer;
use Illuminate\Support\Facades\Storage;

class CustomerController extends Controller
{
    public function index()
    {
        return view('customer.index');
    }

    public function create()
    {
        $brands = Brand::all();
        $products = Product::all();
        $states = DB::select('SELECT id, name FROM states');
        return view('customer.create', compact('brands', 'products','states'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'retailer_id' => 'required|exists:retailers,id',
            'customer_firstname' => 'required|string|max:100',
            'customer_lastname' => 'required|string|max:100',
            'date_of_birth' => 'required|date',
            'father_name' => 'required|string|max:100',
            'address1' => 'required|string|max:255',
            'address2' => 'nullable|string|max:255',
            'nearby' => 'nullable|string|max:255',
            'village' => 'nullable|string|max:255',
            'state_id' => 'required|exists:states,id',
            'city_id' => 'required|exists:cities,id',
            'pincode' => 'required|string|max:10',
            'sell_price' => 'required|numeric',
            'disburst_amount' => 'required|numeric',
            'brand_id' => 'required|exists:brands,id',
            'product_id' => 'required|exists:products,id',
            'imei1' => 'required|string|max:20',
            'imei2' => 'nullable|string|max:20',
            'downpayment' => 'required|numeric',
            'downpayment_pending' => 'required|numeric',
            'emi' => 'required|numeric',
            'months' => 'required|integer',
            'mobile' => 'required|string|max:15',
            'alternate_mobile' => 'nullable|string|max:15',
    
            // File validations
            'selfie' => 'nullable|image|mimes:jpeg,png,jpg|max:10240',
            'adharcard_front' => 'nullable|image|mimes:jpeg,png,jpg|max:10240',
            'adharcard_back' => 'nullable|image|mimes:jpeg,png,jpg|max:10240',
        ]);
    
        // File uploads
        $uploads = [];
        foreach (['selfie', 'adharcard_front', 'adharcard_back'] as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = time() . '_' . $file->getClientOriginalName();
                $path = $file->storeAs('customers', $filename, 'public'); // stored in storage/app/public/customers
                $uploads[$field] = 'storage/' . $path;
            } else {
                $uploads[$field] = null;
            }
        }
    
        // Create customer
        Customer::create([
            'retailer_id' => $validated['retailer_id'],
            'customer_firstname' => $validated['customer_firstname'],
            'customer_lastname' => $validated['customer_lastname'],
            'date_of_birth' => $validated['date_of_birth'],
            'father_name' => $validated['father_name'],
            'address1' => $validated['address1'],
            'address2' => $validated['address2'],
            'nearby' => $validated['nearby'],
            'village' => $validated['village'],
            'state_id' => $validated['state_id'],
            'city_id' => $validated['city_id'],
            'pincode' => $validated['pincode'],
            'sell_price' => $validated['sell_price'],
            'disburst_amount' => $validated['disburst_amount'],
            'brand_id' => $validated['brand_id'],
            'product_id' => $validated['product_id'],
            'imei1' => $validated['imei1'],
            'imei2' => $validated['imei2'],
            'downpayment' => $validated['downpayment'],
            'downpayment_pending' => $validated['downpayment_pending'],
            'emi' => $validated['emi'],
            'months' => $validated['months'],
            'mobile' => $validated['mobile'],
            'alternate_mobile' => $validated['alternate_mobile'],
            'selfie' => $uploads['selfie'],
            'adharcard_front' => $uploads['adharcard_front'],
            'adharcard_back' => $uploads['adharcard_back'],
        ]);
    
        return redirect()->route('retailer.dashboard')->with('success', 'Customer created successfully!');
    }

    public function getProducts($brand_id)
    {
        $products = Product::where('brand_id', $brand_id)
            ->select('id', 'product_name as name')
            ->get();

        return response()->json($products);
    }

    public function getCities($state_id)
    {
        $cities = DB::select('SELECT id, name FROM cities WHERE state_id = ?', [$state_id]);
        return response()->json($cities);
    }
    



}
