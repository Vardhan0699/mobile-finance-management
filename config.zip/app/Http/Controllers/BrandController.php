<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $brands = Brand::all();
        $adminId = session('admin_id'); 
        return view('brand.index', compact('brands','adminId'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('brand.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'brand_name' => 'required|unique:brand,brand_name',
            'brand_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
        ]);

        $imagePath = null;

        if ($request->hasFile('brand_image')) {
            $image = $request->file('brand_image');
            $filename = time() . '_' . $image->getClientOriginalName();
            $path = $image->storeAs('brands', $filename, 'public');
            $imagePath = asset('storage/' . $path);
        }

        Brand::create([
            'brand_name' => $validatedData['brand_name'],
            'brand_image' => $imagePath,
        ]);

        return redirect()->route('admin.brandIndex')->with('success', 'Brand created successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Brand $brand)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $brand = Brand::findOrFail($id);
        return view('brand.edit', compact('brand'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $brand = Brand::findOrFail($id);

        $validatedData = $request->validate([
            'brand_name' => 'required|unique:brand,brand_name,' . $brand->id,
            'brand_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
        ]);

        if ($request->hasFile('brand_image')) {
            // Optional: delete old image if exists
            if ($brand->brand_image) {
                $oldImagePath = str_replace(asset('storage') . '/', '', $brand->brand_image);
                \Storage::disk('public')->delete($oldImagePath);
            }

            $image = $request->file('brand_image');
            $filename = time() . '_' . $image->getClientOriginalName();
            $path = $image->storeAs('brands', $filename, 'public');
            $validatedData['brand_image'] = asset('storage/' . $path); // Store full URL
        }

        $brand->update($validatedData);

        return redirect()->route('admin.brandIndex')->with('success', 'Brand updated successfully!');
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $brand = Brand::findOrFail($id);

        // Optional: delete brand image file if exists
        if ($brand->brand_image) {
            $imagePath = str_replace(asset('storage') . '/', '', $brand->brand_image);
            \Storage::disk('public')->delete($imagePath);
        }

        $brand->delete();

        return redirect()->route('admin.brandIndex')->with('success', 'Brand deleted successfully!');
    }

}
