<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Models\Admin;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        if (session()->has('admin_id')) {
            return redirect()->route('admin.dashboard');
        }
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $admin = DB::table('admin')->where('email', $request->email)->first();

        if ($admin && Hash::check($request->password, $admin->password)) {
            admin_login($admin);  // helper function sets session
            return redirect()->route('admin.dashboard');
        }

        return back()->withErrors(['email' => 'Invalid credentials.']);
    }

    public function logout()
    {
        // Log out the currently authenticated admin
        Auth::logout();

        // Clear the session (optional, but can be useful if you're storing custom session data)
        session()->invalidate();

        // Regenerate the session ID to prevent session fixation attacks
        session()->regenerateToken();

        // Redirect the user to the login page
        return redirect()->route('admin.login');
    }



}
