<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::with('brand')->get();
        $brands = Brand::all();
        return view('product.index', compact('products'));
    }

    public function create()
    {
        $brands = Brand::all();
        return view('product.create', compact('brands'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'product_name' => 'required',
            'brand_id' => 'required|exists:brand,id',
            'product_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
        ]);

        $imagePath = null;

        if ($request->hasFile('product_image')) {
            $image = $request->file('product_image');
            $filename = time() . '_' . $image->getClientOriginalName();
            $path = $image->storeAs('products', $filename, 'public');
            $imagePath = asset('storage/' . $path); // Store full URL
        }

        Product::create([
            'product_name' => $validated['product_name'],
            'brand_id' => $validated['brand_id'],
            'product_image' => $imagePath,
        ]);

        return redirect()->route('admin.productIndex')->with('success', 'Product created successfully!');
    }

    public function edit($id)
{
    // Find the product by its ID
    $product = Product::findOrFail($id);
    $brands = Brand::all(); // Get all available brands

    return view('product.edit', compact('product', 'brands'));
}

public function update(Request $request, $id)
{
    $product = Product::findOrFail($id); // Find the product to update

    $validated = $request->validate([
        'product_name' => 'required',
        'brand_id' => 'required|exists:brands,id',
        'product_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
    ]);

    // If a new image is uploaded, process it
    $imagePath = $product->product_image; // Default to the current image path

    if ($request->hasFile('product_image')) {
        // If a new image is uploaded, store it
        $image = $request->file('product_image');
        $filename = time() . '_' . $image->getClientOriginalName();
        $path = $image->storeAs('products', $filename, 'public');
        $imagePath = asset('storage/' . $path); // Store the full URL of the new image
    }

    // Update product details
    $product->update([
        'product_name' => $validated['product_name'],
        'brand_id' => $validated['brand_id'],
        'product_image' => $imagePath,
    ]);

    return redirect()->route('admin.productIndex')->with('success', 'Product updated successfully!');
}


public function destroy($id)
{
    $product = Product::findOrFail($id); // Find the product to delete

    // Optionally delete the image if needed (if you want to remove the image file from storage)
    if ($product->product_image) {
        $imagePath = str_replace(asset('storage/'), '', $product->product_image);
        Storage::disk('public')->delete($imagePath);
    }

    // Delete the product
    $product->delete();

    return redirect()->route('admin.productIndex')->with('success', 'Product deleted successfully!');
}

}
