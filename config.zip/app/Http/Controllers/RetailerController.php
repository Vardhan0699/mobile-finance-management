<?php

namespace App\Http\Controllers;

use App\Models\Retailer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;


class RetailerController extends Controller
{
    public function index()
    {
        $retailers = Retailer::all();
        return view('retailer.index', compact('retailers'));
    }

    public function create()
    {
        $states = DB::select('SELECT id, name FROM states');
        return view('retailer.create', compact('states'));
    }

    public function getCities($state_id)
    {
        $cities = DB::select('SELECT id, name FROM cities WHERE state_id = ?', [$state_id]);
        return response()->json($cities);
    }


    public function store(Request $request)
    {
        $validated = $request->validate([
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'shop_name' => 'required|string',
            'address1' => 'required|string',
            'address2' => 'nullable|string',
            'state_id' => 'required|integer',
            'city_id' => 'required|integer',
            'zipcode' => 'required|integer',
            'mobile_no' => 'required|string|min:10',
            'email' => 'required|email|unique:retailer,email',
            'password' => 'required|min:6',
        ]);

        $validated['password'] = Hash::make($validated['password']);

        Retailer::create($validated);

        return redirect()->route('admin.retailerIndex')->with('success', 'Retailer created successfully.');
    }
}
