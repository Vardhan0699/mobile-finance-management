<?php

namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

use Illuminate\Database\Eloquent\Model;

class Retailer extends Authenticatable
{
    protected $table = 'retailer';

    protected $fillable = [
        'firstname', 'lastname', 'shop_name', 'address1', 'address2',
        'state_id','city_id', 'zipcode', 'mobile_no', 'email', 'password'
    ];

    protected $hidden = ['password', 'remember_token'];
}
