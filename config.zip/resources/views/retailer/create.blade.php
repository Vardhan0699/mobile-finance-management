@extends('layouts.layout')

@section('content')

<body class="theme-1">
    <div class="page-content-wrapper">
        <div class="content-container">
            <div class="page-content">
                <div class="content-header">
                    <h1>New Retailer</h1>

                </div>
                <form action="{{ route('admin.retailerStore') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-lg-11">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Retailer Information</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">First Name</label>
                                            <input type="text" name="firstname" class="form-control" placeholder="Enter Firstname" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Last Name</label>
                                            <input type="text" name="lastname" class="form-control" placeholder="Enter Lastname" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label">Shop Name</label>
                                            <input type="text" name="shop_name" class="form-control" placeholder="Enter Shop Name"required>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label">Address Line 1</label>
                                            <input type="text" name="address1" class="form-control" placeholder="Enter Address" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label">Address Line 2</label>
                                            <input type="text" name="address2" class="form-control" placeholder="Enter Address">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">State</label>
                                            <select name="state_id" id="state-dropdown" class="form-control" required>
                                                <option value="">Select State</option>
                                                @foreach ($states as $state)
                                                    <option value="{{ $state->id }}">{{ $state->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="col-md-6">
                                            <label class="form-label">City</label>
                                            <select name="city_id" id="city-dropdown" class="form-control" required>
                                                <option value="">Select City</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">ZIPCODE</label>
                                            <input type="text" name="zipcode" class="form-control" maxlength="6" placeholder="Enter Pincode" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Mobile</label>
                                            <input type="text" name="mobile_no" class="form-control" maxlength="10" placeholder="Enter Mobile Number"required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Email</label>
                                            <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Password</label>
                                            <input type="password" name="password" class="form-control" placeholder="Enter Password" required>
                                        </div>
                                    </div>
                                    <div class="text-end mt-4">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="reset" class="btn btn-outline-secondary ms-2">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<!-- jQuery required -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $('#state-dropdown').on('change', function () {
        var stateID = this.value;
        $('#city-dropdown').html('<option value="">Loading...</option>');

        if (stateID) {
            $.ajax({
                url: "/admin/get-cities/" + stateID,
                type: "GET",
                success: function (res) {
                    $('#city-dropdown').html('<option value="">Select City</option>');
                    $.each(res, function (key, value) {
                        $('#city-dropdown').append('<option value="' + value.id + '">' + value.name + '</option>');
                    });
                }
            });
        } else {
            $('#city-dropdown').html('<option value="">Select City</option>');
        }
    });
</script>
<script>
    document.getElementById('upload-image').addEventListener('change', function (event) {
        const file = event.target.files[0];
        const preview = document.getElementById('preview-image');

        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function (e) {
                preview.src = e.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            preview.src = 'https://cdn-icons-png.freepik.com/512/6870/6870041.png';
        }
    });
</script>

@endsection
