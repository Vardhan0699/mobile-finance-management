<!DOCTYPE html>
<html lang="en">

<head>
    <title>Retailer Dashboard</title>
    <!-- Meta -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Dashboard Template Description" />
    <meta name="keywords" content="Dashboard Template" />
    <meta name="author" content="Techne infosys" />

    <!-- Favicon icon -->
    <link rel="icon" href="images/favicon.svg" type="image/x-icon" />

    <!-- font css -->
    <!-- <link rel="stylesheet" href="{{ asset('assets/fonts/tabler-icons.min.css') }}"> -->
    <!-- <link rel="stylesheet" href="{{ asset('assets/fonts/feather.css') }}"> -->
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome.css') }}">
    <link rel="stylesheet" href="{{ asset('fonts/material.css') }}">
    <!-- vendor css -->
    <link rel="stylesheet" href="" id="rtl-style-link">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}" id="main-style-link">
    <link rel="stylesheet" href="{{ asset('css/style-rtl.css') }}" id="main-style-link">
    <link rel="stylesheet" href="{{ asset('css/style-rtl.css.map') }}" id="main-style-link">
    <!-- <link rel="stylesheet" href="{{ asset('css/style-dark.css.map') }}" id="main-style-link"> -->
    <!-- <link rel="stylesheet" href="{{ asset('css/style-dark.css') }}" id="main-style-link"> -->
    <link rel="stylesheet" href="{{ asset('css/style.css.map') }}" id="main-style-link">


    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Include jQuery (optional) if needed for other functionalities -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>



</head>



<body>
    @include('retailerLogin.layout.header')

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 bg-light p-3">
                @include('retailerLogin.layout.navbar')
            </div>
            <div class="col-md-9 p-4">
                @yield('content')
            </div>
        </div>
    </div>

    @include('retailerLogin.layout.footer')
</body>

</html>