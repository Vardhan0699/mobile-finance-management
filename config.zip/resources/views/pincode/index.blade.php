@extends('layouts.layout')

@section('content')

    <body class="theme-1">
        <div class="page-content-wrapper">
            <div class="content-container">
                <div class="page-content">
                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <div class="content-header">
                            <h1>Pincode List</h1>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item">Approve Pincode</li>
                                <li class="breadcrumb-item">Pincode List</li>
                            </ul>
                        </div>
                        <div class="text-end">
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPincodeModal">
                                Add Pincode
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card table-card">
                                        <div
                                            class="card-header card-header d-flex align-items-center justify-content-between">
                                            <h5 class="flex-grow-1">All Pincode</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table" id="pc-dt-export">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center">ID</th>
                                                            <th class="text-center">Pincode</th>
                                                            <th class="text-center">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @forelse($pincodes as $pin)
                                                            <tr>
                                                                <td class="text-center">
                                                                    <div
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <h6 class="mb-0">{{ $loop->iteration }}</h6>
                                                                    </div>
                                                                </td>
                                                                <td class="text-center">
                                                                    {{ optional($pin)->pincode ?? 'No Pincode' }}
                                                                </td>

                                                                <td class="text-center">
                                                                    <a href="javascript:void(0);"
                                                                        class="btn btn-icon btn-sm editPincodeBtn"
                                                                        data-id="{{ $pin->id }}"
                                                                        data-pincode="{{ $pin->pincode }}" title="Edit">
                                                                        <i class="ti ti-pencil"></i>
                                                                    </a>


                                                                    <form
                                                                        action="{{ route('admin.pincodedDestory', $pin->id) }}"
                                                                        method="POST" style="display:inline-block;"
                                                                        onsubmit="return confirm('Are you sure you want to delete this brand?');">
                                                                        @csrf
                                                                        @method('DELETE')
                                                                        <button type="submit"
                                                                            class="btn btn-icon btn-sm text-danger"
                                                                            data-bs-toggle="tooltip" title="Delete">
                                                                            <i class="ti ti-archive"></i>
                                                                        </button>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        @empty
                                                            <tr>
                                                                <td colspan="3" class="px-6 py-4 text-center text-gray-500">No
                                                                    brands found.</td>
                                                            </tr>
                                                        @endforelse
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-5">
                            <div class="dataTables_info" id="pc-dt-simple_info" role="status" aria-live="polite">Showing 1
                                to 5 of 5 entries</div>
                        </div>
                        <div class="col-sm-12 col-md-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="pc-dt-simple_paginate">
                                <ul class="pagination">
                                    <li class="paginate_button page-item previous disabled" id="pc-dt-simple_previous"><a
                                            aria-controls="pc-dt-simple" aria-disabled="true" aria-role="link"
                                            data-dt-idx="previous" tabindex="0" class="page-link">Previous</a></li>
                                    <li class="paginate_button page-item active"><a href="#" aria-controls="pc-dt-simple"
                                            aria-role="link" aria-current="page" data-dt-idx="0" tabindex="0"
                                            class="page-link">1</a></li>
                                    <li class="paginate_button page-item next disabled" id="pc-dt-simple_next"><a
                                            aria-controls="pc-dt-simple" aria-disabled="true" aria-role="link"
                                            data-dt-idx="next" tabindex="0" class="page-link">Next</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="addPincodeModal" tabindex="-1" aria-labelledby="addPincodeModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <form action="{{ route('admin.pincodeStore') }}" method="POST">
                                @csrf
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addPincodeModalLabel">Add New Pincode</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="pincode-name" class="form-label">Pincode</label>
                                            <input type="text" class="form-control" id="pincode-name" name="pincode"
                                                pattern="\d{6}" maxlength="6" minlength="6" title="Please enter pincode"
                                                required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary"
                                            data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>


                    <div class="modal fade" id="editPincodeModal" tabindex="-1" aria-labelledby="editPincodeModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST"  id="editPincodeForm" action="{{ route('admin.pincodeUpdate', $pincode->id ?? 0) }}">
                                @csrf
                                @method('PUT')
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editPincodeModalLabel">Edit Pincode</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" id="editPincodeId">
                                        <div class="mb-3">
                                            <label for="editPincodeInput" class="form-label">Pincode</label>
                                            <input type="text" class="form-control" id="editPincodeInput" name="pincode"
                                                pattern="\d{6}" maxlength="6" minlength="6" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary"
                                            data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        @if ($errors->has('pincode'))
    <div class="alert alert-danger">
        {{ $errors->first('pincode') }}
    </div>
@endif
    </body>
    <!-- Bootstrap JS (with Popper included) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const editButtons = document.querySelectorAll('.editPincodeBtn');
            editButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const id = this.dataset.id;
                    const pincode = this.dataset.pincode;

                    document.getElementById('editPincodeId').value = id;
                    document.getElementById('editPincodeInput').value = pincode;

                    const form = document.getElementById('editPincodeForm');
                    form.action = `/admin/pincode/${id}/update`;

                    const modal = new bootstrap.Modal(document.getElementById('editPincodeModal'));
                    modal.show();
                });
            });
        });
    </script>

<script>
    @if ($errors->has('pincode'))
        var myModal = new bootstrap.Modal(document.getElementById('addPincodeModal'));
        myModal.show();
    @endif
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Edit button logic
        const editButtons = document.querySelectorAll('.editPincodeBtn');
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                const id = this.dataset.id;
                const pincode = this.dataset.pincode;

                document.getElementById('editPincodeId').value = id;
                document.getElementById('editPincodeInput').value = pincode;

                const form = document.getElementById('editPincodeForm');
                form.action = `/admin/pincode/${id}/update`;

                const modal = new bootstrap.Modal(document.getElementById('editPincodeModal'));
                modal.show();
            });
        });

        // Initialize DataTable
        $('#pc-dt-export').DataTable({
            pageLength: 10, // Show 10 entries per page
            lengthMenu: [5, 10, 25, 50, 100],
            ordering: true,
            responsive: true
        });
    });
</script>


@endsection