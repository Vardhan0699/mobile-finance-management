@extends('retailerLogin.layout.layout')

@section('content')

    <body class="theme-1">
        <form action="" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="page-content-wrapper">
                <div class="content-container">
                    <div class="page-content">
                        <div class="content-header">
                            <h1>New Customer</h1>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <!-- Customer Documents Upload -->
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h4>Upload Documents</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group mb-3">
                                            <label>Selfie</label>
                                            <div class="position-relative overflow-hidden rounded">
                                                <img id="preview-image"
                                                    src="https://cdn-icons-png.freepik.com/512/6870/6870041.png" alt="image"
                                                    class="w-100 mb-3" style="max-height: 200px; object-fit: cover;">
                                            </div>
                                            <input type="file" name="selfie" class="form-control mt-3">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label>Aadhar Front</label>
                                            <div class="position-relative overflow-hidden rounded">
                                                <img id="preview-image"
                                                    src="https://cdn-icons-png.freepik.com/512/6870/6870041.png" alt="image"
                                                    class="w-100 mb-3" style="max-height: 200px; object-fit: cover;">
                                            </div>
                                            <input type="file" name="adharcard_front" class="form-control">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label>Aadhar Back</label>
                                            <div class="position-relative overflow-hidden rounded">
                                                <img id="preview-image"
                                                    src="https://cdn-icons-png.freepik.com/512/6870/6870041.png" alt="image"
                                                    class="w-100 mb-3" style="max-height: 200px; object-fit: cover;">
                                            </div>
                                            <input type="file" name="adharcard_back" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Customer Information</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            @php $retailerId = session('retailer_id'); @endphp
                                            <input type="hidden" name="retailer_id" value="{{ $retailerId }}">

                                            <div class="col-md-6 mb-3">
                                                <label>First Name</label>
                                                <input type="text" name="firstname" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Last Name</label>
                                                <input type="text" name="lastname" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Date of Birth</label>
                                                <input type="date" name="date_of_birth" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Father's Name</label>
                                                <input type="text" name="father_name" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Address 1</label>
                                                <input type="text" name="address1" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Address 2</label>
                                                <input type="text" name="address2" class="form-control">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label>Nearby</label>
                                                <input type="text" name="nearby" class="form-control">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label>Village</label>
                                                <input type="text" name="village" class="form-control">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label>State</label>
                                                <select name="state_id" id="state_id" class="form-select" required>
                                                    <option value="">Select State</option>
                                                    @foreach ($states as $state)
                                                        <option value="{{ $state->id }}">{{ $state->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>City</label>
                                                <select name="city_id" id="city_id" class="form-select" required disabled>
                                                    <option value="">Select City</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Pincode</label>
                                                <input type="text" name="pincode" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Sell Price</label>
                                                <input type="number" name="sell_price" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Disburst Amount</label>
                                                <input type="number" name="disburst_amount" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Brand</label>
                                                <select name="brand_id" id="brand_id" class="form-select" required>
                                                    <option value="">Select Brand</option>
                                                    @foreach ($brands as $brand)
                                                        <option value="{{ $brand->id }}">{{ $brand->brand_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>

                                            <div class="col-md-6 mb-3">
                                                <label>Product</label>
                                                <select name="product_id" id="product_id" class="form-select" required>
                                                    <option value="">Select Product</option>
                                                </select>
                                            </div>

                                            <div class="col-md-6 mb-3">
                                                <label>IMEI 1</label>
                                                <input type="text" name="imei1" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>IMEI 2</label>
                                                <input type="text" name="imei2" class="form-control">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label>Down Payment</label>
                                                <input type="number" name="downpayment" class="form-control" required>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label>Pending Down Payment</label>
                                                <input type="number" name="downpayment_pending" class="form-control"
                                                    required>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label>EMI</label>
                                                <input type="number" name="emi" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Months</label>
                                                <input type="number" name="months" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Mobile</label>
                                                <input type="text" name="mobile" class="form-control" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Alternate Mobile</label>
                                                <input type="text" name="alternate_mobile" class="form-control">
                                            </div>
                                        </div>
                                        <div class="text-end">
                                            <button class="btn btn-primary">Submit</button>
                                            <button type="reset" class="btn btn-outline-secondary ms-2">Reset</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>

    </body>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $('#product_id').prop('disabled', true);

        $('#brand_id').on('change', function () {
            let brandId = $(this).val();
            $('#product_id').prop('disabled', true).html('<option value="">Loading...</option>');

            if (brandId) {
                $.ajax({
                    url: '/retailer/get-products/' + brandId,
                    type: 'GET',
                    success: function (products) {
                        let options = '<option value="">Select Product</option>';
                        $.each(products, function (key, product) {
                            options += '<option value="' + product.id + '">' + product.name + '</option>';
                        });
                        $('#product_id').html(options).prop('disabled', false);
                    }
                });
            } else {
                $('#product_id').html('<option value="">Select Product</option>').prop('disabled', true);
            }
        });

    </script>

    <script>
        $('#state_id').on('change', function () {
            let stateID = $(this).val();
            $('#city_id').prop('disabled', true).html('<option value="">Loading...</option>');

            if (stateID) {
                $.ajax({
                    url: "/retailer/get-cities/" + stateID,

                    type: "GET",
                    success: function (res) {
                        let options = '<option value="">Select City</option>';
                        $.each(res, function (key, value) {
                            options += '<option value="' + value.id + '">' + value.name + '</option>';
                        });
                        $('#city_id').html(options).prop('disabled', false);
                    },
                    error: function (xhr) {
                        console.error("City load failed:", xhr.responseText);
                        $('#city_id').html('<option value="">Failed to load cities</option>').prop('disabled', true);
                    }
                });
            }
        });

    </script>

@endsection