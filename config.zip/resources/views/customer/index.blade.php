@extends('retailerLogin.layout.layout')

@section('content')

<body class="theme-1">

</body>

@endsection