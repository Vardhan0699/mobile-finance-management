<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\PincodeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\Retailer\RetailerLoginController;
use App\Http\Controllers\Retailer\RetailerRegisterController;
use App\Http\Controllers\RetailerController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\BrandController;


Route::get('/', function () {
    return view('retailerLogin.auth.login');
});

// Route::get('/phpinfo', function () {
//     phpinfo();
// });

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('login/submit', [LoginController::class, 'login'])->name('login.submit');
    Route::post('logout', [LoginController::class, 'logout'])->name('logout');
    Route::get('/get-cities/{state_id}', [RetailerController::class, 'getCities']);


    Route::middleware('adminAuth')->group(function () {

        Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');

        Route::get('pincode/index', [PincodeController::class, 'index'])->name('pincodeIndex');
        Route::get('pincode/create', [PincodeController::class, 'create'])->name('pincodeCreate');
        Route::post('pincode/store', [PincodeController::class, 'store'])->name('pincodeStore');
        Route::get('pincode/{id}/edit', [PincodeController::class, 'edit'])->name('pincodeEdit');
        Route::put('pincode/{id}/update', [PincodeController::class, 'update'])->name('pincodeUpdate');
        Route::delete('pincode/{id}', [PincodeController::class, 'destroy'])->name('pincodedDestory');


        Route::get('retailer/index', [RetailerController::class, 'index'])->name('retailerIndex');
        Route::get('retailer/create', [RetailerController::class, 'create'])->name('retailerCreate');
        Route::post('retailer/store', [RetailerController::class, 'store'])->name('retailerStore');
    });

});


Route::prefix('retailer')->name('retailer.')->group(function () {

    Route::get('/login', [RetailerLoginController::class, 'showLoginForm'])->name('loginForm');
    Route::post('/login/submit', [RetailerLoginController::class, 'login'])->name('login');
    Route::post('/logout', [RetailerLoginController::class, 'logout'])->name('logout');

    Route::get('/register', [RetailerRegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [RetailerRegisterController::class, 'register'])->name('register.submit');
    Route::get('/get-cities/{state_id}', [CustomerController::class, 'getCities']);

    Route::middleware('retailer.auth')->group(function () {
        Route::get('/dashboard', [RetailerLoginController::class, 'dashboard'])->name('dashboard');
        Route::get('brand/index', [BrandController::class, 'index'])->name('brandIndex');
        Route::get('brand/create', [BrandController::class, 'create'])->name('brandCreate');
        Route::post('brand/store', [BrandController::class, 'store'])->name('brandStore');
        Route::get('brand/{id}/edit', [BrandController::class, 'edit'])->name('brandEdit');
        Route::put('brand/{id}/update', [BrandController::class, 'update'])->name('brandUpdate');
        Route::delete('brand/{id}', [BrandController::class, 'destroy'])->name('brandDestroy');


        Route::get('product/index', [ProductController::class, 'index'])->name('productIndex');
        Route::get('product/create', [ProductController::class, 'create'])->name('productCreate');
        Route::post('product/store', [ProductController::class, 'store'])->name('productStore');
        Route::get('product/{id}/edit', [ProductController::class, 'edit'])->name('productEdit');
        Route::put('product/{id}', [ProductController::class, 'update'])->name('productUpdate');
        Route::delete('product/{id}', [ProductController::class, 'destroy'])->name('productDestroy');
        
        Route::get('/customer/index', [CustomerController::class, 'index'])->name('customerIndex');
        Route::get('/customer/create', [CustomerController::class, 'create'])->name('customerCreate');
        Route::get('/customer/store', [CustomerController::class, 'store'])->name('customerStore');

        Route::get('/get-products/{brand_id}', [CustomerController::class, 'getProducts']);
        
        
    });

});